const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
dotenv.config();
const app = express();
const port = 3000;

const axios = require("axios");

const APP_ID = process.env.CLIENT_APP_Id;
const SECRET_KEY = process.env.CLIENT_SECRET_KEY;

//  For Testing
const BASE_URL = "https://sandbox.cashfree.com/pg/orders";
//  For Production
// const BASE_URL = "https://api.cashfree.com/pg/orders"

app.use(
	cors({
		origin: "*",
		credentials: true,
	})
);

app.use(bodyParser.json());

app.post("/api/createOrder", (req, res) => {
	try {
		const options = {
			method: "POST",
			url: BASE_URL,
			headers: {
				accept: "application/json",
				"x-api-version": "2023-08-01",
				"content-type": "application/json",
				"x-client-id": APP_ID,
				"x-client-secret": SECRET_KEY,
			},
			data: {
				customer_details: {
					customer_id: "customer" + Date.now(),
					customer_email: req.body.UserEmail,
					customer_phone: req.body.UserMobile,
					customer_name: req.body.UserName,
				},
				order_id: "order" + Date.now(),
				order_amount: req.body.OrderAmount,
				order_currency: "INR",
				order_note: req.body.OrderDesc,
				order_meta: {
					return_url: `http://localhost:49508/result/${"order" + Date.now()}`,
				},
			},
		};

		axios
			.request(options)
			.then(function (response) {
				console.log(response.data);
				res.status(200).json({
					payment_id: response.data.payment_session_id,
					order_id: response.data.order_id,
					msg: "Order Created",
				});
			})
			.catch(function (error) {
				console.error(error);
				res.status(500).json({
					error: error,
					msg: "Order Not Created !!!",
				});
			});
	} catch (error) {
		res.status(500).json({ msg: "Error in Creating Order" });
	}
});

app.get("/api/status/:order_id", (req, res) => {
	const orderId = req.params.order_id;
	try {
		const options = {
			method: "GET",
			url: `${BASE_URL}/${orderId}`,
			headers: {
				accept: "application/json",
				"x-api-version": "2023-08-01",
				"x-client-id": APP_ID,
				"x-client-secret": SECRET_KEY,
			},
		};

		axios
			.request(options)
			.then(function (response) {
				console.log(response.data);

				if (response.data.order_status == "PAID") {
					res.status(200).json({
						order_status: "PAID",
						msg: "Error in Verifying Order",
					});
				} else {
					res.status(200).json({
						order_status: "FAILED",
						msg: "Error in Verifying Order",
					});
				}
			})
			.catch(function (error) {
				console.error(error);
			});
	} catch (error) {
		res.status(500).json({ msg: "Error in Verifying Order" });
	}
});

app.listen(port, () => {
	console.log(`Server running at http://127.0.0.1:${port}/`);
});
